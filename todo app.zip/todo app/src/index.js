
import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function TodoList() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');

  const handleChange = event => setNewTask(event.target.value);

  const handleSubmit = event => {
    event.preventDefault();
    if (!newTask.trim()) return;
    setTasks([...tasks, newTask]);
    setNewTask('');
  };

  const handleDelete = index => {
    const newTasks = [...tasks];
    newTasks.splice(index, 1);
    setTasks(newTasks);
  };

  return (
    <div>
      <h1>Todo List using Webpack</h1>
      <form onSubmit={handleSubmit}>
        <input value={newTask} onChange={handleChange} placeholder="New task" />
        <button>Submit Task</button>
      </form>
      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            {task}
            <button onClick={() => handleDelete(index)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

ReactDOM.render(<TodoList />, document.getElementById('root'));
